# Spring Team Project (3조)  🧑‍🤝‍🧑💻 💪

* 프로젝트명: 
* 조원: **배예슬(PM)**, 최종현, 장예진, 이원준, 정효재, 신명근 (총 6명)
* 역할: 
> 1. PM + Design & Presentation - 1명 (PM, 디자인 및 발표) - 배예슬
>  2. Plannig & Basic Setup - 1명 (기획) - 장예진
> 3. DB Connection & SQL Query - 1명 (DB) - 이원준
>  4. LoginController, Login View - 1명 (로그인) - 신명근
>  5. ChartController, Chart View - 1명 (차트) - 장예진, 배예슬
>  6. BoardController, Board View - 1명 (게시판) - 최종현, 정효재

* 프로젝트 일정:
>  1. 2021.09.03: 첫 모임. 역할 분배
>  2. 2021.09.08: 각 기능 구현 문제시 서로 feedback 
>  3. 2021.09.10: 최종 기능 합치기
>  4. 2021.09.11~ : Front-end 데이터 시각화 및 디자인 수정
>  5. 2021.09.17: 프로젝트 발표
