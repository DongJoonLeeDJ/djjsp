package com.mh.jpa02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jpa02Application {

	public static void main(String[] args) {
		SpringApplication.run(Jpa02Application.class, args);
	}

}
