#pragma once

const char *pGetASCIIName (int code);