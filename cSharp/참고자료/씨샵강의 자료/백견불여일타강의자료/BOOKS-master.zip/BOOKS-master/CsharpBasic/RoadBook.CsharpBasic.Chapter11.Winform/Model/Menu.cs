﻿namespace RoadBook.CsharpBasic.Chapter11.Winform.Model
{
    public class Menu
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Price { get; set; }
    }
}