﻿namespace RoadBook.CsharpBasic.Chapter12.Examples
{
    public class Ex005
    {
        public void Run()
        {
            Manager.SearchManager sm = new Manager.SearchManager();

            sm.Run();
        }
    }
}