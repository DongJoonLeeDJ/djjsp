﻿namespace RoadBook.CsharpBasic.Chapter12.Examples
{
    public class Ex004
    {
        public void Run()
        {
            Manager.IndexManager im = new Manager.IndexManager();

            im.Run();
        }
    }
}