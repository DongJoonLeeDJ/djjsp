﻿namespace RoadBook.CsharpBasic.Chapter12.Examples
{
    public class Ex003
    {
        public void Run()
        {
            Manager.CrawlManager cm = new Manager.CrawlManager();

            cm.Run();
        }
    }
}