﻿namespace RoadBook.CsharpBasic.Chapter09.Model
{
    public class Student
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int Grade { get; set; }
        public string Major { get; set; }
    }
}