﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;
using System.Web.UI;

namespace RoadBook.CsharpBasic.Chapter10.Web
{
    public class BundleConfig
    {
        // 묶음에 대한 자세한 내용은 https://go.microsoft.com/fwlink/?LinkID=303951을 참조하세요.
        public static void RegisterBundles(BundleCollection bundles)
        {
        }
    }
}