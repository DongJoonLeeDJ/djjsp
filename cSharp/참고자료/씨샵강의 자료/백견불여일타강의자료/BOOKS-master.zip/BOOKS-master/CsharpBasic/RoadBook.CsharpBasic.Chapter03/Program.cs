﻿namespace RoadBook.CsharpBasic.Chapter03
{
    class Program
    {
        static void Main(string[] args)
        {
            Examples.Ex001 ex = new Examples.Ex001();

            ex.Run();
        }
    }
}