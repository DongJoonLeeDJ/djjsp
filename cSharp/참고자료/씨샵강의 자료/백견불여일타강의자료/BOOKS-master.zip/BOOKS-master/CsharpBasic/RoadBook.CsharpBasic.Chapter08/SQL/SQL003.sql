﻿USE testdb

INSERT INTO TB_USER ( ID, NAME, AGE, JOB )
VALUES ( 'U001', '유저', '20', '학생' )

INSERT INTO TB_USER ( ID, NAME, AGE, JOB )
VALUES ( 'U002', '유저', '28', '디자이너' )

INSERT INTO TB_USER ( ID, NAME, AGE, JOB )
VALUES ( 'U003', '유저', '30', '프로그래머' )

INSERT INTO TB_USER ( ID, NAME, AGE, JOB )
VALUES ( 'U004', '유저', '25', '요리사' )

INSERT INTO TB_USER ( ID, NAME, AGE, JOB )
VALUES ( 'U005', '유저', '32', '교사' )