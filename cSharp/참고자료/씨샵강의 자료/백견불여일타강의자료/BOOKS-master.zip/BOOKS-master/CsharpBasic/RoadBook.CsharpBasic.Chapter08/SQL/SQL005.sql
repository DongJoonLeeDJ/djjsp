﻿USE testdb

UPDATE
	TB_USER
SET
	NAME = '유저_수정'
WHERE
	ID = 'U001'