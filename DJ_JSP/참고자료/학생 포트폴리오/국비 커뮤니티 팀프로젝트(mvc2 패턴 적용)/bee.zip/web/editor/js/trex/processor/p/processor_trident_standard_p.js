
Trex.I.Processor.TridentStandardP = {

};
