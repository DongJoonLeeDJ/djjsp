package com.kb.www.constants;

public class Constants {
    public static final int MEMBER_HISTORY_EVENT_JOIN = 1;
    public static final int MEMBER_HISTORY_EVENT_UPDATE = 2;
    public static final int MEMBER_HISTORY_EVENT_LEAVE = 3;
    public static final int MEMBER_HISTORY_EVENT_LOGIN = 4;
    public static final int MEMBER_HISTORY_EVENT_LOGOUT = 5;
}
